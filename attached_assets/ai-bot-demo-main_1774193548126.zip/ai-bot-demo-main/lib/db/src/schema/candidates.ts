import { pgTable, text, serial, integer, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { interviewsTable } from "./interviews";
import { sessionsTable } from "./sessions";

export const candidatesTable = pgTable("candidates", {
  id: serial("id").primaryKey(),
  interviewId: integer("interview_id").notNull().references(() => interviewsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  email: text("email"),
  inviteToken: uuid("invite_token").notNull().unique().defaultRandom(),
  status: text("status").notNull().default("invited"),
  sessionId: integer("session_id").references(() => sessionsTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCandidateSchema = createInsertSchema(candidatesTable).omit({ id: true, createdAt: true, inviteToken: true, status: true, sessionId: true });
export type InsertCandidate = z.infer<typeof insertCandidateSchema>;
export type Candidate = typeof candidatesTable.$inferSelect;
