import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const interviewsTable = pgTable("interviews", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  jobDescription: text("job_description").notNull(),
  questions: text("questions").array().notNull().default([]),
  durationMinutes: integer("duration_minutes").notNull().default(30),
  voiceGender: text("voice_gender").notNull().default("female"),
  experienceLevel: text("experience_level").notNull().default("medium"),
  codingEnabled: boolean("coding_enabled").notNull().default(false),
  humanAvatarEnabled: boolean("human_avatar_enabled").notNull().default(false),
  idVerificationRequired: boolean("id_verification_required").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertInterviewSchema = createInsertSchema(interviewsTable).omit({ id: true, createdAt: true });
export type InsertInterview = z.infer<typeof insertInterviewSchema>;
export type Interview = typeof interviewsTable.$inferSelect;
