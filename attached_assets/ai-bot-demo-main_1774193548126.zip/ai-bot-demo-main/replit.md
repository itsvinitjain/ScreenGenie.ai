# Overview

This project is a full-stack AI-powered interview system, "EaseMyHire," designed to revolutionize the hiring process. It features a React and Vite frontend, an Express API server, a PostgreSQL database, and extensive integration with OpenAI for various AI functionalities. The system aims to provide a continuous, in-depth, and fair evaluation of candidates through AI-driven interviews, including real-time performance assessment, cheating detection, and optional code evaluation. The business vision is to streamline technical recruitment by offering a consistent, unbiased, and scalable interview solution.

# User Preferences

I prefer iterative development, where we focus on one feature or section at a time. I prefer concise responses, under 60 words, and clear explanations. Before making any major architectural changes or significant code refactors, please ask for my approval. I want detailed explanations for complex AI behaviors or new feature implementations. Do not make changes to files in the `lib/api-client-react/` or `lib/api-zod/` directories, as these are generated.

# System Architecture

The project is structured as a pnpm monorepo using TypeScript (v5.9) and Node.js (v24).

**Frontend:**
*   React 19 with Vite, Tailwind CSS for styling, and Wouter for routing.
*   **UI/UX:** Dark sci-fi/futuristic theme with cyan and purple accents.
    *   **Jarvis-like Orb:** Animated using `framer-motion` (cyan for idle, green for listening, purple for thinking, bright cyan for speaking).
    *   **Human Avatar Interviewer:** Optional SVG-animated character that replaces the orb. Features realistic lip-sync mouth animation when speaking, eye blinking, head nodding (listening), thinking tilt, and idle breathing. Gender-matched to voice selection (male/female). Rendered entirely in CSS+SVG with no static images.
*   **Feature Specifications:**
    *   **Dashboard:** For organizers to create and manage interviews, candidates, and invite links.
    *   **Live Interview:** Features a countdown timer, real-time AI questioning, and a "PROCTORED" badge with a live webcam feed.
    *   **Results:** Displays a 7-dimension evaluation radar chart, AI integrity check, detailed scores, and verdict.
    *   **In-Interview Code Editor:** Optional Monaco editor with multi-language execution (via Wandbox API) and a split-pane layout for coding assessments. Automatically detects relevant roles to enable the editor.

**Backend (API Server):**
*   Express 5 API server.
*   **Core Logic:** Manages interview sessions, AI interactions, proctoring, ID verification, and code execution.
*   **AI Interview Logic:**
    *   **Question Depth:** Progressive 4-phase depth progression (warm-up, technical, complex, stress-testing) based on elapsed time.
    *   **Cheating Detection:** AI monitors for suspicious behavior (e.g., textbook answers, inconsistent depth) and employs countermeasures.
    *   **Continuous Interview:** Ensures AI continuously asks questions for the full duration, with server-side time validation.
    *   **TTS Optimization:** Inline TTS generation on the server-side reduces latency by embedding audio data directly into SSE `done` events.
*   **Proctoring & Activity Tracking:** Tracks tab switches, focus loss, and other proctoring events, storing them in the database.
*   **Government ID Verification:** Pre-interview gate using GPT-4o-mini vision to verify ID validity, name match, and photo presence.
*   **Code Execution:** Proxies code execution requests to the Wandbox API, handling 20 languages and a 15-second timeout.

**Database:**
*   PostgreSQL with Drizzle ORM.
*   **Schema:** `interviews`, `sessions`, `session_messages` tables to store interview configurations, candidate session data, and conversation history.

**API Design:**
*   RESTful API with routes for managing interviews, sessions, and code execution.
*   Uses Server-Sent Events (SSE) for streaming AI question/response generation.
*   Orval for API client and Zod schema generation from OpenAPI specifications.

**Monorepo Structure:**
*   `api-server`: Express API.
*   `interview-app`: React frontend.
*   `lib/api-spec`: OpenAPI specification.
*   `lib/api-client-react`: Generated React Query hooks.
*   `lib/api-zod`: Generated Zod schemas.
*   `lib/db`: Drizzle ORM schema and DB connection.
*   `lib/integrations-openai-ai-server`: OpenAI integration logic.

**Build and Type-checking:**
*   `pnpm workspaces` for monorepo management.
*   `esbuild` for CJS bundle.
*   `tsc --build --emitDeclarationOnly` for type-checking, ensuring `.d.ts` files are generated.

# External Dependencies

*   **Database:** PostgreSQL
*   **ORM:** Drizzle ORM
*   **AI/ML:**
    *   OpenAI API:
        *   `gpt-4o`: Main interview logic and comprehensive evaluation.
        *   `gpt-4o-mini`: First question generation, ID verification (vision), and audio transcription.
        *   `gpt-audio`: Text-to-speech (TTS) for AI responses.
*   **Code Execution:** Wandbox API (https://wandbox.org/api/compile.json)
*   **Validation:** Zod (`zod/v4`), `drizzle-zod`
*   **API Codegen:** Orval
*   **UI Components:** Monaco Editor (`@monaco-editor/react`)
*   **Animation:** `framer-motion`