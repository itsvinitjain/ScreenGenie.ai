import { Router, type IRouter } from "express";
import healthRouter from "./health";
import interviewsRouter from "./interviews/index";
import sessionsRouter from "./sessions/index";
import codeRouter from "./code/index";
import candidatesRouter from "./candidates/index";

const router: IRouter = Router();

router.use(healthRouter);
router.use(interviewsRouter);
router.use(sessionsRouter);
router.use(codeRouter);
router.use(candidatesRouter);

export default router;
