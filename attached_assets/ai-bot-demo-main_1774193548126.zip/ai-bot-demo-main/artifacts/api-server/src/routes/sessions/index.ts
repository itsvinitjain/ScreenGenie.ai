import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, interviewsTable, sessionsTable, sessionMessagesTable, candidatesTable } from "@workspace/db";
import {
  CreateSessionBody,
  GetSessionParams,
  SendSessionMessageParams,
  SendSessionMessageBody,
  TextToSpeechParams,
  TextToSpeechBody,
  TranscribeAudioParams,
  TranscribeAudioBody,
  EndSessionParams,
  GetNextQuestionParams,
} from "@workspace/api-zod";
import {
  streamInterviewResponse,
  generateEvaluation,
  getInitialStrictness,
  getVoiceForGender,
  getStrictnessLimits,
  analyzeCodeSubmission,
} from "../../lib/interviewAI";
import { textToSpeech } from "@workspace/integrations-openai-ai-server/audio";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

function getElapsedSeconds(startedAt: Date | null): number {
  if (!startedAt) return 0;
  return Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000);
}

function getElapsedMinutes(startedAt: Date | null): number {
  return Math.floor(getElapsedSeconds(startedAt) / 60);
}

function isTimeExceeded(startedAt: Date | null, durationMinutes: number): boolean {
  return getElapsedSeconds(startedAt) >= durationMinutes * 60;
}

interface AIResponseMetadata {
  response?: string;
  newStrictness?: number;
  timeAllotted?: number;
  isFollowUp?: boolean;
  questionNumber?: number;
  depthLevel?: number;
  suspicionLevel?: number;
  suspicionNotes?: string;
}

function clampMetadata(metadata: AIResponseMetadata, experienceLevel: string, currentQuestionsAsked: number) {
  const limits = getStrictnessLimits(experienceLevel);
  const strictness = typeof metadata.newStrictness === 'number'
    ? Math.max(limits.min, Math.min(limits.max, Math.round(metadata.newStrictness)))
    : limits.initial;
  const timeAllotted = typeof metadata.timeAllotted === 'number'
    ? Math.max(30, Math.min(180, Math.round(metadata.timeAllotted)))
    : 60;
  const questionNumber = typeof metadata.questionNumber === 'number' && metadata.questionNumber > 0
    ? metadata.questionNumber
    : currentQuestionsAsked + 1;
  return { ...metadata, newStrictness: strictness, timeAllotted, questionNumber };
}

router.post("/sessions", async (req, res): Promise<void> => {
  const parsed = CreateSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, parsed.data.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  const initialStrictness = getInitialStrictness(interview.experienceLevel);

  const [session] = await db
    .insert(sessionsTable)
    .values({
      interviewId: parsed.data.interviewId,
      candidateName: parsed.data.candidateName,
      status: "active",
      currentStrictness: initialStrictness,
      questionsAsked: 0,
      startedAt: new Date(),
    })
    .returning();

  res.status(201).json(session);
});

router.get("/sessions/:id", async (req, res): Promise<void> => {
  const params = GetSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, session.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  const messages = await db
    .select()
    .from(sessionMessagesTable)
    .where(eq(sessionMessagesTable.sessionId, session.id))
    .orderBy(sessionMessagesTable.createdAt);

  const elapsedSec = getElapsedSeconds(session.startedAt);
  const remainingSeconds = Math.max(0, interview.durationMinutes * 60 - elapsedSec);

  res.json({
    session,
    interview,
    messages,
    elapsedMinutes: Math.floor(elapsedSec / 60),
    remainingSeconds,
    isTimeUp: elapsedSec >= interview.durationMinutes * 60,
  });
});

router.post("/sessions/:id/message", async (req, res): Promise<void> => {
  const params = SendSessionMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = SendSessionMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (session.status !== "active") {
    res.status(400).json({ error: "Session is not active" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, session.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  if (isTimeExceeded(session.startedAt, interview.durationMinutes)) {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.write(`data: ${JSON.stringify({ type: "done", response: "Thank you for your time. The interview duration has ended. We will now generate your evaluation.", timeUp: true })}\n\n`);
    res.end();
    return;
  }

  const elapsedMinutes = getElapsedMinutes(session.startedAt);
  const elapsedSec = getElapsedSeconds(session.startedAt);
  const remainingMinutes = Math.max(0, (interview.durationMinutes * 60 - elapsedSec) / 60);

  await db.insert(sessionMessagesTable).values({
    sessionId: session.id,
    role: "candidate",
    content: parsed.data.content,
  });

  const existingMessages = await db
    .select()
    .from(sessionMessagesTable)
    .where(eq(sessionMessagesTable.sessionId, session.id))
    .orderBy(sessionMessagesTable.createdAt);

  const conversationHistory = existingMessages.map((m) => ({
    role: m.role,
    content: m.content,
  }));

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let aiResponse = "";
  let metadata: AIResponseMetadata | null = null;

  for await (const event of streamInterviewResponse({
    jobDescription: interview.jobDescription,
    questions: interview.questions || [],
    experienceLevel: interview.experienceLevel,
    durationMinutes: interview.durationMinutes,
    voiceGender: interview.voiceGender,
    candidateName: session.candidateName,
    currentStrictness: session.currentStrictness,
    questionsAsked: session.questionsAsked,
    elapsedMinutes,
    remainingMinutes,
    conversationHistory,
    codingEnabled: interview.codingEnabled,
    candidateTimezone: req.body?.candidateTimezone || "UTC",
  })) {
    if (event.type === "content") {
      res.write(`data: ${JSON.stringify({ type: "content", content: event.data })}\n\n`);
    } else if (event.type === "metadata") {
      metadata = event.data;
    }
  }

  if (metadata) {
    const clamped = clampMetadata(metadata, interview.experienceLevel, session.questionsAsked);
    aiResponse = clamped.response || "";

    const voice = getVoiceForGender(interview.voiceGender || "female");
    const [, , audioBuffer] = await Promise.all([
      db.insert(sessionMessagesTable).values({
        sessionId: session.id,
        role: "interviewer",
        content: aiResponse,
        questionNumber: clamped.questionNumber,
        timeAllotted: clamped.timeAllotted,
      }),
      db
        .update(sessionsTable)
        .set({
          currentStrictness: clamped.newStrictness,
          questionsAsked: clamped.questionNumber,
        })
        .where(eq(sessionsTable.id, session.id)),
      aiResponse ? textToSpeech(aiResponse, voice, "mp3") : Promise.resolve(null),
    ]);

    const audioBase64 = audioBuffer ? audioBuffer.toString("base64") : undefined;

    res.write(
      `data: ${JSON.stringify({
        type: "done",
        response: aiResponse,
        newStrictness: clamped.newStrictness,
        timeAllotted: clamped.timeAllotted,
        questionNumber: clamped.questionNumber,
        audioBase64,
      })}\n\n`
    );
  }

  res.end();
});

router.post("/sessions/:id/next-question", async (req, res): Promise<void> => {
  const params = GetNextQuestionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (session.status !== "active") {
    res.status(400).json({ error: "Session is not active" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, session.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  if (interview.idVerificationRequired && !session.idVerified) {
    res.status(403).json({ error: "ID verification required before starting the interview" });
    return;
  }

  if (isTimeExceeded(session.startedAt, interview.durationMinutes)) {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.write(`data: ${JSON.stringify({ type: "done", response: "Thank you for your time. The interview duration has ended. We will now generate your evaluation.", timeUp: true })}\n\n`);
    res.end();
    return;
  }

  const elapsedMinutes = getElapsedMinutes(session.startedAt);
  const elapsedSec = getElapsedSeconds(session.startedAt);
  const remainingMinutes = Math.max(0, (interview.durationMinutes * 60 - elapsedSec) / 60);

  const existingMessages = await db
    .select()
    .from(sessionMessagesTable)
    .where(eq(sessionMessagesTable.sessionId, session.id))
    .orderBy(sessionMessagesTable.createdAt);

  const conversationHistory = existingMessages.map((m) => ({
    role: m.role,
    content: m.content,
  }));

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let aiResponse = "";
  let metadata: AIResponseMetadata | null = null;

  for await (const event of streamInterviewResponse({
    jobDescription: interview.jobDescription,
    questions: interview.questions || [],
    experienceLevel: interview.experienceLevel,
    durationMinutes: interview.durationMinutes,
    voiceGender: interview.voiceGender,
    candidateName: session.candidateName,
    currentStrictness: session.currentStrictness,
    questionsAsked: session.questionsAsked,
    elapsedMinutes,
    remainingMinutes,
    conversationHistory,
    codingEnabled: interview.codingEnabled,
    candidateTimezone: req.body?.candidateTimezone || "UTC",
  })) {
    if (event.type === "content") {
      res.write(`data: ${JSON.stringify({ type: "content", content: event.data })}\n\n`);
    } else if (event.type === "metadata") {
      metadata = event.data;
    }
  }

  if (metadata) {
    const clamped = clampMetadata(metadata, interview.experienceLevel, session.questionsAsked);
    aiResponse = clamped.response || "";

    const voice = getVoiceForGender(interview.voiceGender || "female");
    const [, , audioBuffer] = await Promise.all([
      db.insert(sessionMessagesTable).values({
        sessionId: session.id,
        role: "interviewer",
        content: aiResponse,
        questionNumber: clamped.questionNumber,
        timeAllotted: clamped.timeAllotted,
      }),
      db
        .update(sessionsTable)
        .set({
          currentStrictness: clamped.newStrictness,
          questionsAsked: clamped.questionNumber,
        })
        .where(eq(sessionsTable.id, session.id)),
      aiResponse ? textToSpeech(aiResponse, voice, "mp3") : Promise.resolve(null),
    ]);

    const audioBase64 = audioBuffer ? audioBuffer.toString("base64") : undefined;

    res.write(
      `data: ${JSON.stringify({
        type: "done",
        response: aiResponse,
        newStrictness: clamped.newStrictness,
        timeAllotted: clamped.timeAllotted,
        questionNumber: clamped.questionNumber,
        audioBase64,
      })}\n\n`
    );
  }

  res.end();
});

router.post("/sessions/:id/code-submission", async (req, res): Promise<void> => {
  const params = SendSessionMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { code, language, output } = req.body;
  if (!code || !language) {
    res.status(400).json({ error: "code and language are required" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (session.status !== "active") {
    res.status(400).json({ error: "Session is not active" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, session.interviewId));

  if (!interview || !interview.codingEnabled) {
    res.status(400).json({ error: "Coding is not enabled for this interview" });
    return;
  }

  const executionOutput = output || "";
  const hasOutput = !!output;
  const executionSuccess = hasOutput && !executionOutput.includes("Error") && !executionOutput.includes("error:");
  
  const analysis = await analyzeCodeSubmission(
    code,
    language,
    executionOutput,
    interview.jobDescription,
  );

  const structuredSubmission = {
    language: language.toUpperCase(),
    code,
    execution: {
      stdout: executionOutput,
      success: executionSuccess,
      hasOutput,
    },
    approachDescription: analysis.approachDescription,
    aiAssessment: analysis.aiAssessment,
    qualityScore: analysis.qualityScore,
    submittedAt: new Date().toISOString(),
  };

  const content = `[CODE SUBMISSION - ${language.toUpperCase()}]\n\`\`\`${language}\n${code}\n\`\`\`\n\nExecution Output:\n\`\`\`\n${executionOutput || "(not executed)"}\n\`\`\`\n\nApproach: ${analysis.approachDescription}\nAssessment: ${analysis.aiAssessment}\nQuality Score: ${analysis.qualityScore}/10\n\n[STRUCTURED_METADATA]: ${JSON.stringify(structuredSubmission)}`;

  await db.insert(sessionMessagesTable).values({
    sessionId: session.id,
    role: "code",
    content,
  });

  res.json({ ok: true });
});

router.post("/sessions/:id/verify-id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid session id" });
    return;
  }

  const { imageBase64, candidateName } = req.body;
  if (!imageBase64) {
    res.status(400).json({ error: "imageBase64 is required" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  try {
    const { openai } = await import("@workspace/integrations-openai-ai-server");

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 512,
      messages: [
        {
          role: "system",
          content: `You are an ID verification system. Analyze the image to determine if it shows a valid government-issued ID document (passport, driver's license, national ID card, Aadhaar card, voter ID, etc). Check:
1. Is there a clearly visible government ID in the image?
2. Can you read a name on the ID?
3. Does the ID appear genuine (not obviously fake/edited)?
4. Is there a photo on the ID?

The candidate's claimed name is: "${candidateName || session.candidateName}"

Respond in JSON format:
{
  "isValidId": boolean,
  "idType": string (e.g., "Driver's License", "Passport", "National ID"),
  "nameOnId": string (name visible on ID, or "unreadable"),
  "nameMatch": boolean (does name on ID roughly match candidate name),
  "hasPhoto": boolean,
  "confidence": number (0-100),
  "reason": string (brief explanation)
}`
        },
        {
          role: "user",
          content: [
            { type: "text", text: "Please verify this government ID document." },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`,
                detail: "high"
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
    });

    const resultText = response.choices[0]?.message?.content || "{}";
    let verificationResult;
    try {
      verificationResult = JSON.parse(resultText);
    } catch {
      verificationResult = { isValidId: false, reason: "Failed to parse verification response" };
    }

    const verified = verificationResult.isValidId === true 
      && verificationResult.confidence >= 50
      && verificationResult.hasPhoto === true;

    if (verified) {
      await db.update(sessionsTable).set({
        idVerified: true,
        idVerificationData: verificationResult,
      }).where(eq(sessionsTable.id, id));
    }

    res.json({
      verified,
      ...verificationResult,
    });
  } catch (err) {
    console.error("ID verification error:", err);
    res.status(500).json({ error: "ID verification failed" });
  }
});

router.post("/sessions/:id/proctor-event", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid session id" });
    return;
  }

  const { type, timestamp, details } = req.body;
  if (!type || !timestamp) {
    res.status(400).json({ error: "type and timestamp required" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const updates: Record<string, unknown> = {};
  const flags = Array.isArray(session.proctoringFlags) ? [...(session.proctoringFlags as string[])] : [];

  if (type === "tab_switch") {
    updates.tabSwitchCount = (session.tabSwitchCount || 0) + 1;
    flags.push(`TAB_SWITCH:${timestamp}`);
  } else if (type === "focus_lost") {
    updates.focusLostCount = (session.focusLostCount || 0) + 1;
    flags.push(`FOCUS_LOST:${timestamp}`);
  } else if (type === "tab_returned" || type === "focus_returned") {
    flags.push(`${type.toUpperCase()}:${timestamp}`);
  } else if (type === "paste_detected") {
    flags.push(`PASTE_DETECTED|${timestamp}|${details || ""}`);
  } else if (type === "looking_away" || type === "face_not_visible") {
    flags.push(`${type.toUpperCase()}|${timestamp}|${details || ""}`);
  }

  updates.proctoringFlags = flags;

  await db.update(sessionsTable).set(updates).where(eq(sessionsTable.id, id));
  res.json({ ok: true });
});

router.post("/sessions/:id/speak", async (req, res): Promise<void> => {
  const params = TextToSpeechParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = TextToSpeechBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, session.interviewId));

  const voice = parsed.data.voice || getVoiceForGender(interview?.voiceGender || "female");

  const audioBuffer = await textToSpeech(parsed.data.text, voice, "mp3");
  const audioBase64 = audioBuffer.toString("base64");

  res.json({ audioBase64 });
});

router.post("/sessions/:id/transcribe", async (req, res): Promise<void> => {
  const params = TranscribeAudioParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = TranscribeAudioBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const audioBuffer = Buffer.from(parsed.data.audioBase64, "base64");

  const { ensureCompatibleFormat } = await import("@workspace/integrations-openai-ai-server/audio");
  const { buffer, format } = await ensureCompatibleFormat(audioBuffer);

  const file = new File([buffer], `audio.${format}`, {
    type: format === "wav" ? "audio/wav" : `audio/${format}`,
  });

  const transcription = await openai.audio.transcriptions.create({
    model: "gpt-4o-mini-transcribe",
    file,
    response_format: "json",
  });

  res.json({ text: transcription.text });
});

router.post("/sessions/:id/end", async (req, res): Promise<void> => {
  const params = EndSessionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, params.data.id));

  if (!session) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  if (session.status === "completed") {
    try {
      const stored = JSON.parse(session.feedback || "{}");
      if (stored._fullEvaluation) {
        res.json(stored._fullEvaluation);
        return;
      }
    } catch {}
    res.json({
      session,
      scores: { overall: session.overallScore },
      feedback: session.feedback,
      strengths: [],
      improvements: [],
      aiSuspicionReport: "",
      finalVerdict: "",
    });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, session.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  const messages = await db
    .select()
    .from(sessionMessagesTable)
    .where(eq(sessionMessagesTable.sessionId, session.id))
    .orderBy(sessionMessagesTable.createdAt);

  const conversationHistory = messages.map((m) => ({
    role: m.role,
    content: m.content,
  }));

  const elapsedMinutes = getElapsedMinutes(session.startedAt);
  const elapsedSec = getElapsedSeconds(session.startedAt);
  const remainingMinutes = Math.max(0, (interview.durationMinutes * 60 - elapsedSec) / 60);

  const evaluation = await generateEvaluation({
    jobDescription: interview.jobDescription,
    questions: interview.questions || [],
    experienceLevel: interview.experienceLevel,
    durationMinutes: interview.durationMinutes,
    voiceGender: interview.voiceGender,
    candidateName: session.candidateName,
    currentStrictness: session.currentStrictness,
    questionsAsked: session.questionsAsked,
    elapsedMinutes,
    remainingMinutes,
    conversationHistory,
    codingEnabled: interview.codingEnabled,
  });

  const responsePayload = {
    scores: {
      technical: evaluation.technical,
      communication: evaluation.communication,
      problemSolving: evaluation.problemSolving,
      confidence: evaluation.confidence,
      depthOfUnderstanding: evaluation.depthOfUnderstanding,
      emotionalResilience: evaluation.emotionalResilience,
      pressureHandling: evaluation.pressureHandling,
      codeQuality: evaluation.codeQuality,
      overall: evaluation.overall,
    },
    feedback: evaluation.feedback,
    strengths: evaluation.strengths,
    improvements: evaluation.improvements,
    aiSuspicionReport: evaluation.aiSuspicionReport,
    finalVerdict: evaluation.finalVerdict,
  };

  const feedbackJson = JSON.stringify({ _fullEvaluation: responsePayload, text: evaluation.feedback });

  const [updatedSession] = await db
    .update(sessionsTable)
    .set({
      status: "completed",
      endedAt: new Date(),
      overallScore: evaluation.overall,
      feedback: feedbackJson,
    })
    .where(eq(sessionsTable.id, session.id))
    .returning();

  await db
    .update(candidatesTable)
    .set({ status: "completed" })
    .where(eq(candidatesTable.sessionId, session.id));

  res.json({ session: updatedSession, ...responsePayload });
});

export default router;
