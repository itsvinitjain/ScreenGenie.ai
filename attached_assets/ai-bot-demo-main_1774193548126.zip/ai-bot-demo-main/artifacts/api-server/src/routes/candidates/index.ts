import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, candidatesTable, interviewsTable, sessionsTable } from "@workspace/db";
import { getInitialStrictness } from "../../lib/interviewAI";

const router: IRouter = Router();

router.get("/interviews/:id/candidates", async (req, res): Promise<void> => {
  const interviewId = parseInt(req.params.id);
  if (isNaN(interviewId)) {
    res.status(400).json({ error: "Invalid interview ID" });
    return;
  }

  const candidates = await db
    .select()
    .from(candidatesTable)
    .where(eq(candidatesTable.interviewId, interviewId));

  res.json(candidates);
});

router.post("/interviews/:id/candidates", async (req, res): Promise<void> => {
  const interviewId = parseInt(req.params.id);
  if (isNaN(interviewId)) {
    res.status(400).json({ error: "Invalid interview ID" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  const { candidates } = req.body;
  if (!Array.isArray(candidates) || candidates.length === 0) {
    res.status(400).json({ error: "candidates array is required" });
    return;
  }

  const created = [];
  for (const c of candidates) {
    if (!c.name || typeof c.name !== "string") continue;
    const [candidate] = await db.insert(candidatesTable).values({
      interviewId,
      name: c.name.trim(),
      email: c.email?.trim() || null,
    }).returning();
    created.push(candidate);
  }

  res.json(created);
});

router.delete("/candidates/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid candidate ID" });
    return;
  }

  await db.delete(candidatesTable).where(eq(candidatesTable.id, id));
  res.json({ ok: true });
});

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

router.get("/invite/:token", async (req, res): Promise<void> => {
  const { token } = req.params;

  if (!UUID_REGEX.test(token)) {
    res.status(404).json({ error: "Invalid invite link" });
    return;
  }

  const [candidate] = await db
    .select()
    .from(candidatesTable)
    .where(eq(candidatesTable.inviteToken, token));

  if (!candidate) {
    res.status(404).json({ error: "Invalid invite link" });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, candidate.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  let session = null;
  if (candidate.sessionId) {
    const [existingSession] = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.id, candidate.sessionId));
    session = existingSession || null;
  }

  res.json({
    candidate: {
      id: candidate.id,
      name: candidate.name,
      email: candidate.email,
      status: candidate.status,
    },
    interview: {
      id: interview.id,
      title: interview.title,
      durationMinutes: interview.durationMinutes,
      codingEnabled: interview.codingEnabled,
    },
    session: session ? { id: session.id, status: session.status } : null,
  });
});

router.post("/invite/:token/start", async (req, res): Promise<void> => {
  const { token } = req.params;

  if (!UUID_REGEX.test(token)) {
    res.status(404).json({ error: "Invalid invite link" });
    return;
  }

  const [candidate] = await db
    .select()
    .from(candidatesTable)
    .where(eq(candidatesTable.inviteToken, token));

  if (!candidate) {
    res.status(404).json({ error: "Invalid invite link" });
    return;
  }

  if (candidate.sessionId) {
    const [existingSession] = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.id, candidate.sessionId));

    if (existingSession && existingSession.status !== "completed") {
      res.json({ sessionId: existingSession.id, resumed: true });
      return;
    }

    if (existingSession && existingSession.status === "completed") {
      res.status(400).json({ error: "This interview has already been completed" });
      return;
    }
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, candidate.interviewId));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  const initialStrictness = getInitialStrictness(interview.experienceLevel);

  const [session] = await db.insert(sessionsTable).values({
    interviewId: interview.id,
    candidateName: candidate.name,
    status: "active",
    currentStrictness: initialStrictness,
    startedAt: new Date(),
  }).returning();

  await db
    .update(candidatesTable)
    .set({ sessionId: session.id, status: "started" })
    .where(eq(candidatesTable.id, candidate.id));

  res.json({ sessionId: session.id, resumed: false });
});

export default router;
