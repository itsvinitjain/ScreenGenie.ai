import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, interviewsTable, sessionsTable } from "@workspace/db";
import {
  CreateInterviewBody,
  GetInterviewParams,
  GetInterviewResponse,
  UpdateInterviewParams,
  UpdateInterviewBody,
  UpdateInterviewResponse,
  DeleteInterviewParams,
  ListInterviewSessionsParams,
} from "@workspace/api-zod";
import { getInitialStrictness } from "../../lib/interviewAI";

const router: IRouter = Router();

router.get("/interviews", async (_req, res): Promise<void> => {
  const interviews = await db
    .select()
    .from(interviewsTable)
    .orderBy(desc(interviewsTable.createdAt));
  res.json(interviews);
});

router.post("/interviews", async (req, res): Promise<void> => {
  const parsed = CreateInterviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const [interview] = await db
    .insert(interviewsTable)
    .values({
      title: data.title,
      jobDescription: data.jobDescription,
      questions: data.questions || [],
      durationMinutes: data.durationMinutes,
      voiceGender: data.voiceGender,
      experienceLevel: data.experienceLevel,
      codingEnabled: data.codingEnabled ?? false,
      humanAvatarEnabled: data.humanAvatarEnabled ?? false,
      idVerificationRequired: data.idVerificationRequired ?? false,
    })
    .returning();

  res.status(201).json(interview);
});

router.get("/interviews/:id", async (req, res): Promise<void> => {
  const params = GetInterviewParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [interview] = await db
    .select()
    .from(interviewsTable)
    .where(eq(interviewsTable.id, params.data.id));

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  res.json(interview);
});

router.patch("/interviews/:id", async (req, res): Promise<void> => {
  const params = UpdateInterviewParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateInterviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [interview] = await db
    .update(interviewsTable)
    .set(parsed.data)
    .where(eq(interviewsTable.id, params.data.id))
    .returning();

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  res.json(interview);
});

router.delete("/interviews/:id", async (req, res): Promise<void> => {
  const params = DeleteInterviewParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [interview] = await db
    .delete(interviewsTable)
    .where(eq(interviewsTable.id, params.data.id))
    .returning();

  if (!interview) {
    res.status(404).json({ error: "Interview not found" });
    return;
  }

  res.sendStatus(204);
});

router.get("/interviews/:id/sessions", async (req, res): Promise<void> => {
  const params = ListInterviewSessionsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const sessions = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.interviewId, params.data.id))
    .orderBy(desc(sessionsTable.createdAt));

  res.json(sessions);
});

export default router;
