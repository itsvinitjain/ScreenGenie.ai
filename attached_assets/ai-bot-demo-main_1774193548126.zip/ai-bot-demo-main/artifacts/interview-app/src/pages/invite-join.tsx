import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Code, Shield, Mic } from "lucide-react";

const API_BASE = `${import.meta.env.BASE_URL}api`.replace(/\/+/g, "/");

interface InviteData {
  candidate: { id: number; name: string; email: string | null; status: string };
  interview: { id: number; title: string; durationMinutes: number; codingEnabled: boolean };
  session: { id: number; status: string } | null;
}

export default function InviteJoin() {
  const { token } = useParams<{ token: string }>();
  const [, setLocation] = useLocation();
  const [inviteData, setInviteData] = useState<InviteData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [starting, setStarting] = useState(false);

  useEffect(() => {
    if (!token) return;
    fetch(`${API_BASE}/invite/${token}`)
      .then(r => {
        if (!r.ok) throw new Error("Invalid or expired invite link");
        return r.json();
      })
      .then(data => {
        setInviteData(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, [token]);

  const handleStart = async () => {
    if (!token) return;
    setStarting(true);

    try {
      const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStream.getTracks().forEach(t => t.stop());
    } catch {
      setError("Microphone access is required for the interview. Please enable it and try again.");
      setStarting(false);
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/invite/${token}/start`, { method: "POST" });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to start interview");
      }
      const { sessionId } = await res.json();
      setLocation(`/interview/${sessionId}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to start interview");
      setStarting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse-glow w-16 h-16 rounded-full bg-primary/20 border-2 border-primary" />
      </div>
    );
  }

  if (error || !inviteData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle className="text-destructive">Invalid Invite</CardTitle>
            <CardDescription>{error || "This invite link is not valid."}</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (inviteData.session?.status === "completed") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle>Interview Completed</CardTitle>
            <CardDescription>
              You have already completed this interview. Thank you for participating!
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button variant="outline" onClick={() => setLocation(`/results/${inviteData.session!.id}`)}>
              View Results
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (inviteData.session && inviteData.session.status !== "completed") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <CardTitle>Resume Interview</CardTitle>
            <CardDescription>
              You have an interview session in progress.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button onClick={() => setLocation(`/interview/${inviteData.session!.id}`)}>
              Continue Interview
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background relative flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-10 pointer-events-none" />

      <Card className="max-w-lg w-full relative z-10">
        <CardHeader className="text-center pb-2">
          <div className="text-xs uppercase tracking-widest text-primary font-bold mb-2">You're Invited</div>
          <CardTitle className="text-2xl">{inviteData.interview.title}</CardTitle>
          <CardDescription className="mt-2">
            Welcome, <span className="text-foreground font-medium">{inviteData.candidate.name}</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2 p-3 rounded-lg bg-white/5 border border-white/10">
              <Clock className="w-4 h-4 text-primary" />
              <div>
                <div className="text-sm font-medium">{inviteData.interview.durationMinutes} min</div>
                <div className="text-xs text-muted-foreground">Duration</div>
              </div>
            </div>
            {inviteData.interview.codingEnabled && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-white/5 border border-white/10">
                <Code className="w-4 h-4 text-primary" />
                <div>
                  <div className="text-sm font-medium">Code Editor</div>
                  <div className="text-xs text-muted-foreground">Included</div>
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 p-3 rounded-lg bg-white/5 border border-white/10">
              <Mic className="w-4 h-4 text-primary" />
              <div>
                <div className="text-sm font-medium">Voice AI</div>
                <div className="text-xs text-muted-foreground">Interviewer</div>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 rounded-lg bg-white/5 border border-white/10">
              <Shield className="w-4 h-4 text-primary" />
              <div>
                <div className="text-sm font-medium">Unique</div>
                <div className="text-xs text-muted-foreground">Session</div>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-1">Before you begin:</p>
            <ul className="space-y-1 list-disc pl-4 text-xs">
              <li>Ensure you're in a quiet environment</li>
              <li>Microphone access will be required</li>
              <li>The interview will begin immediately</li>
              <li>Answer naturally — the AI adapts to your level</li>
            </ul>
          </div>

          <Button
            className="w-full"
            size="lg"
            onClick={handleStart}
            disabled={starting}
          >
            {starting ? "Starting Interview..." : "Begin Interview"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
