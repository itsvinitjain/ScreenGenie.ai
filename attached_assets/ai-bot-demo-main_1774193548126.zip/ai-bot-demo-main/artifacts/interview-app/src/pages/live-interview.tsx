import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import { Activity, Mic, MicOff, AlertTriangle, Clock, Shield, Play, Code2, MessageSquare, GripVertical, Camera, ShieldCheck } from "lucide-react";
import { JarvisOrb } from "@/components/JarvisOrb";
import { InterviewerAvatar } from "@/components/InterviewerAvatar";
import { StrictnessMeter } from "@/components/StrictnessMeter";
import { CodeEditor } from "@/components/CodeEditor";
import { Button } from "@/components/ui/button";
import { CameraProctor } from "@/components/CameraProctor";
import { IdVerification } from "@/components/IdVerification";
import { useSession, useEndSessionMutation } from "@/hooks/use-sessions";
import { useInterviewFlow } from "@/hooks/use-interview-flow";

function formatTime(totalSeconds: number): string {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export default function LiveInterview() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const [, setLocation] = useLocation();
  const numSessionId = parseInt(sessionId, 10);
  
  const { data: sessionData, isLoading: isSessionLoading } = useSession(numSessionId);
  const endSessionMutation = useEndSessionMutation();

  const {
    orbState,
    currentQuestionText,
    transcript,
    isRecording,
    isTimeUp,
    audioUnlocked,
    unlockAudio,
    triggerNextQuestion,
    submitAnswer,
    forceEndInterview
  } = useInterviewFlow(numSessionId, sessionData?.interview?.voiceGender || 'female');

  const initialized = useRef(false);
  const [started, setStarted] = useState(false);
  const [idVerified, setIdVerified] = useState(false);
  const [preStartCountdown, setPreStartCountdown] = useState<number | null>(null);
  const preStartRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoEndTriggered = useRef(false);
  const endTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (endTimeoutRef.current) clearTimeout(endTimeoutRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
      if (preStartRef.current) clearInterval(preStartRef.current);
    };
  }, []);

  useEffect(() => {
    if (sessionData?.session?.startedAt && sessionData?.interview?.durationMinutes) {
      const startTime = new Date(sessionData.session.startedAt).getTime();
      const durationMs = sessionData.interview.durationMinutes * 60 * 1000;
      const endTime = startTime + durationMs;

      const updateCountdown = () => {
        const remaining = Math.max(0, Math.floor((endTime - Date.now()) / 1000));
        setCountdown(remaining);

        if (remaining <= 0 && !autoEndTriggered.current) {
          autoEndTriggered.current = true;
          if (countdownRef.current) clearInterval(countdownRef.current);
          forceEndInterview().then(() => {
            endTimeoutRef.current = setTimeout(() => {
              if (!mountedRef.current) return;
              endSessionMutation.mutateAsync({ id: numSessionId }).then(() => {
                if (mountedRef.current) setLocation(`/results/${numSessionId}`);
              });
            }, 8000);
          });
        }
      };

      updateCountdown();
      countdownRef.current = setInterval(updateCountdown, 1000);

      return () => {
        if (countdownRef.current) clearInterval(countdownRef.current);
      };
    }
  }, [sessionData?.session?.startedAt, sessionData?.interview?.durationMinutes, numSessionId, setLocation, endSessionMutation, forceEndInterview]);

  useEffect(() => {
    if (isTimeUp && !autoEndTriggered.current) {
      autoEndTriggered.current = true;
      forceEndInterview().then(() => {
        endTimeoutRef.current = setTimeout(() => {
          if (!mountedRef.current) return;
          endSessionMutation.mutateAsync({ id: numSessionId }).then(() => {
            if (mountedRef.current) setLocation(`/results/${numSessionId}`);
          });
        }, 8000);
      });
    }
  }, [isTimeUp, numSessionId, setLocation, endSessionMutation, forceEndInterview]);

  const handleStartInterview = () => {
    unlockAudio();
    setPreStartCountdown(5);
    preStartRef.current = setInterval(() => {
      setPreStartCountdown(prev => {
        if (prev === null || prev <= 1) {
          if (preStartRef.current) clearInterval(preStartRef.current);
          preStartRef.current = null;
          setStarted(true);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  useEffect(() => {
    if (started && audioUnlocked && sessionData?.session && !initialized.current && sessionData.session.status === 'active' && sessionData.session.questionsAsked === 0) {
      initialized.current = true;
      triggerNextQuestion();
    }
  }, [started, audioUnlocked, sessionData?.session, triggerNextQuestion]);

  useEffect(() => {
    if (sessionData?.session && sessionData.session.questionsAsked > 0 && !started) {
      setStarted(true);
      unlockAudio();
    }
  }, [sessionData?.session, started, unlockAudio]);

  useEffect(() => {
    if (sessionData?.session?.status === 'completed') {
      setLocation(`/results/${numSessionId}`);
    }
  }, [sessionData?.session?.status, numSessionId, setLocation]);

  const [mobileTab, setMobileTab] = useState<'interview' | 'code'>('interview');
  const codingEnabled = sessionData?.interview?.codingEnabled ?? false;
  const humanAvatarEnabled = (sessionData?.interview as any)?.humanAvatarEnabled ?? false;
  const idVerificationRequired = (sessionData?.interview as any)?.idVerificationRequired ?? false;
  const voiceGender = sessionData?.interview?.voiceGender || "female";
  const [splitPercent, setSplitPercent] = useState(40);
  const isDragging = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleDividerMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";

    const onMouseMove = (ev: MouseEvent) => {
      if (!isDragging.current || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const pct = ((ev.clientX - rect.left) / rect.width) * 100;
      setSplitPercent(Math.min(70, Math.max(25, pct)));
    };

    const onMouseUp = () => {
      isDragging.current = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };

    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  }, []);

  const handleSubmitCode = useCallback(async (code: string, language: string, output: string) => {
    if (isTimeUp) return;
    try {
      await fetch(`/api/sessions/${numSessionId}/code-submission`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language, output }),
      });
    } catch (err) {
      console.error("Failed to submit code:", err);
    }
  }, [numSessionId, isTimeUp]);

  const handleMaxViolations = useCallback(async () => {
    autoEndTriggered.current = true;
    try {
      await endSessionMutation.mutateAsync({ id: numSessionId });
    } catch {}
    if (mountedRef.current) setLocation(`/results/${numSessionId}`);
  }, [numSessionId, endSessionMutation, setLocation]);

  const handleEndSession = async () => {
    if (confirm("Are you sure you want to terminate the interview early?")) {
      await endSessionMutation.mutateAsync({ id: numSessionId });
      setLocation(`/results/${numSessionId}`);
    }
  };

  if (isSessionLoading) {
    return <div className="min-h-screen bg-black flex items-center justify-center text-primary font-mono animate-pulse">Establishing Neural Link...</div>;
  }

  if (sessionData?.session?.status === 'completed') {
    return <div className="min-h-screen bg-black flex items-center justify-center text-primary font-mono animate-pulse">Redirecting to results...</div>;
  }

  const isFinalWarning = countdown !== null && countdown <= 10 && countdown > 0;
  const isLowTime = countdown !== null && countdown < 300;
  const isCriticalTime = countdown !== null && countdown < 60;
  const isCodingPhase = codingEnabled && countdown !== null && countdown <= 600 && countdown > 0;
  const progressPercent = countdown !== null && sessionData?.interview?.durationMinutes
    ? Math.round(((sessionData.interview.durationMinutes * 60 - countdown) / (sessionData.interview.durationMinutes * 60)) * 100)
    : 0;

  if (preStartCountdown !== null) {
    return (
      <div className="min-h-screen bg-black text-foreground relative overflow-hidden flex flex-col items-center justify-center font-sans">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-10 mix-blend-screen" />
        </div>

        <div className="relative z-10 flex flex-col items-center gap-8 max-w-lg text-center px-6">
          {humanAvatarEnabled
            ? <InterviewerAvatar state="idle" gender={voiceGender as "male" | "female"} />
            : <JarvisOrb state="idle" className="scale-125 md:scale-150" />
          }

          <div className="space-y-4">
            <p className="text-sm font-mono uppercase tracking-widest text-primary/80">
              Preparing your interview
            </p>
            <div className="relative w-28 h-28 mx-auto">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="44" fill="none" stroke="hsl(217 91% 60% / 0.15)" strokeWidth="4" />
                <circle
                  cx="50" cy="50" r="44"
                  fill="none"
                  stroke="hsl(217 91% 60%)"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 44}`}
                  strokeDashoffset={`${2 * Math.PI * 44 * (1 - preStartCountdown / 5)}`}
                  style={{ transition: "stroke-dashoffset 0.9s ease-in-out" }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-4xl font-bold text-white font-mono">{preStartCountdown}</span>
              </div>
            </div>
            <p className="text-white/60 text-sm">
              Interview starts in <span className="text-white font-semibold">{preStartCountdown}</span> {preStartCountdown === 1 ? 'second' : 'seconds'}
            </p>
            <p className="text-xs text-white/40">
              Get ready. Your interviewer will greet you shortly.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!started && sessionData?.session?.questionsAsked === 0) {
    const needsIdVerification = idVerificationRequired && !idVerified;

    return (
      <div className="min-h-screen bg-black text-foreground relative overflow-hidden flex flex-col items-center justify-center font-sans">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-10 mix-blend-screen" />
        </div>

        <div className="relative z-10 flex flex-col items-center gap-8 max-w-2xl text-center px-6">
          {!needsIdVerification && (
            humanAvatarEnabled
              ? <InterviewerAvatar state="idle" gender={voiceGender as "male" | "female"} />
              : <JarvisOrb state="idle" className="scale-125 md:scale-150" />
          )}

          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-white tracking-tight">
              {sessionData?.interview?.title || "Interview"}
            </h1>
            <p className="text-muted-foreground font-mono text-sm">
              CANDIDATE: {sessionData?.session?.candidateName}
            </p>
            <p className="text-muted-foreground text-sm mt-2">
              Duration: {sessionData?.interview?.durationMinutes} minutes
            </p>
          </div>

          {needsIdVerification ? (
            <IdVerification
              sessionId={numSessionId}
              candidateName={sessionData?.session?.candidateName || ""}
              onVerified={() => setIdVerified(true)}
            />
          ) : (
            <>
              <div className="space-y-3">
                <p className="text-sm text-white/70 leading-relaxed">
                  Please make sure your speakers or headphones are on.
                  The AI interviewer will speak all questions aloud.
                  Your microphone will be used to record your answers.
                </p>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 border border-primary/20 text-xs text-primary">
                  <Camera className="w-4 h-4 flex-shrink-0" />
                  <span>Camera proctoring will be enabled. Your webcam and activity will be monitored throughout the interview.</span>
                </div>
                {idVerificationRequired && idVerified && (
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-green-500/10 border border-green-500/20 text-xs text-green-400">
                    <ShieldCheck className="w-4 h-4 flex-shrink-0" />
                    <span>Identity verified successfully. You may now proceed.</span>
                  </div>
                )}
              </div>

              <Button
                size="lg"
                variant="glow"
                className="w-64 h-14 text-lg font-display uppercase tracking-widest"
                onClick={handleStartInterview}
              >
                <Play className="w-5 h-5 mr-2" />
                Begin Interview
              </Button>
            </>
          )}
        </div>
      </div>
    );
  }

  const interviewPanel = (
    <div className={`flex flex-col ${codingEnabled ? 'h-full' : 'flex-1'}`}>
      <main className={`flex-1 flex flex-col items-center justify-center relative z-10 px-4 ${codingEnabled ? 'py-4' : ''}`}>
        {humanAvatarEnabled
          ? <InterviewerAvatar state={orbState} gender={voiceGender as "male" | "female"} className={`mb-8 ${codingEnabled ? '' : 'mb-12'} transition-transform duration-1000`} />
          : <JarvisOrb state={orbState} className={`mb-8 ${codingEnabled ? 'scale-100 md:scale-110' : 'mb-12 scale-125 md:scale-150'} transition-transform duration-1000`} />
        }
        
        <div className="h-8 flex items-center justify-center mb-6">
          {orbState === 'thinking' && !isTimeUp && (
            <span className="text-accent font-mono animate-pulse tracking-widest uppercase text-sm">
              {(sessionData?.session?.questionsAsked || 0) === 0 ? "Preparing Your Interview..." : "Processing Response..."}
            </span>
          )}
          {orbState === 'speaking' && !isTimeUp && <span className="text-primary font-mono animate-pulse tracking-widest uppercase text-sm">AI is Speaking...</span>}
          {orbState === 'listening' && !isTimeUp && <span className="text-green-400 font-mono animate-pulse tracking-widest uppercase flex items-center gap-2 text-sm"><Mic className="w-4 h-4"/> Recording Audio...</span>}
          {isTimeUp && <span className="text-red-400 font-mono animate-pulse tracking-widest uppercase flex items-center gap-2 text-sm"><AlertTriangle className="w-4 h-4"/> Interview Complete</span>}
        </div>

        <div className={`w-full mx-auto flex items-end justify-center ${codingEnabled ? 'max-w-xl h-28' : 'max-w-3xl h-40'}`}>
          <p className={`text-center font-light text-white/90 leading-relaxed drop-shadow-lg ${codingEnabled ? 'text-base md:text-lg' : 'text-xl md:text-2xl'}`}>
            {currentQuestionText || transcript || (orbState === 'listening' ? "Speak your answer..." : "")}
          </p>
        </div>
      </main>

      <div className={`relative z-10 px-4 pb-4 flex justify-center items-center gap-4 ${codingEnabled ? 'pt-2' : 'p-6 md:p-8 border-t border-white/5 bg-gradient-to-t from-black to-transparent'}`}>
        <Button variant="destructive" size="sm" className="opacity-50 hover:opacity-100" onClick={handleEndSession} disabled={isTimeUp}>
          <AlertTriangle className="w-4 h-4 mr-2" /> Terminate
        </Button>

        {!codingEnabled && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs font-mono text-muted-foreground">
            <Shield className="w-3.5 h-3.5 text-primary" />
            <span>AI Detection Active</span>
          </div>
        )}

        <div className="flex items-center justify-center h-10 px-4 rounded-xl bg-white/5 border border-white/10 font-mono text-xs text-muted-foreground pointer-events-none">
          <MicOff className="w-3.5 h-3.5 mr-1.5 text-red-500 opacity-50" />
          Mute Disabled
        </div>
        
        <Button 
          size={codingEnabled ? "default" : "lg"}
          variant={orbState === 'listening' ? "glow" : "secondary"}
          className={`${codingEnabled ? 'w-36' : 'w-48'} font-display uppercase tracking-widest`}
          onClick={submitAnswer}
          disabled={orbState !== 'listening' || isTimeUp}
        >
          {isTimeUp ? "Time Up" : orbState === 'listening' ? "Submit Answer" : "Standby"}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-foreground relative overflow-hidden flex flex-col font-sans">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-10 mix-blend-screen" />
        {orbState === 'speaking' && <div className="absolute inset-0 bg-primary/5 animate-pulse" />}
        {orbState === 'listening' && <div className="absolute inset-0 bg-green-500/5 animate-pulse" />}
        {orbState === 'thinking' && <div className="absolute inset-0 bg-accent/5 animate-pulse" />}
      </div>

      {isCodingPhase && !isFinalWarning && !isTimeUp && (
        <div className="relative z-20 bg-gradient-to-r from-accent/90 to-primary/90 text-white text-center py-2.5 px-4 shadow-[0_0_20px_rgba(var(--accent),0.3)]">
          <div className="flex items-center justify-center gap-3 font-mono font-bold tracking-widest uppercase text-sm">
            <Code2 className="w-5 h-5 animate-pulse" />
            Coding Phase — Use the Code Editor
            <Code2 className="w-5 h-5 animate-pulse" />
          </div>
        </div>
      )}

      {isFinalWarning && (
        <div className="relative z-20 bg-red-600 text-white text-center py-3 px-4 animate-pulse shadow-[0_0_30px_rgba(239,68,68,0.5)]">
          <div className="flex items-center justify-center gap-3 font-mono font-bold tracking-widest uppercase text-sm">
            <AlertTriangle className="w-5 h-5" />
            Interview ending in {countdown} seconds
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>
      )}

      {isTimeUp && (
        <div className="relative z-20 bg-red-900/90 text-white text-center py-3 px-4">
          <div className="flex items-center justify-center gap-3 font-mono font-bold tracking-widest uppercase text-sm">
            <Clock className="w-5 h-5" />
            Interview Complete — Generating Report...
          </div>
        </div>
      )}

      <header className="relative z-10 flex justify-between items-start p-4 md:p-6">
        <div className="flex items-start gap-4">
          <CameraProctor sessionId={numSessionId} isActive={started && !isTimeUp} onMaxViolations={handleMaxViolations} />
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 text-primary font-display tracking-widest text-sm uppercase">
              <Activity className="w-4 h-4 animate-pulse" />
              System Active
              {codingEnabled && (
                <span className="ml-2 flex items-center gap-1 text-accent">
                  <Code2 className="w-3.5 h-3.5" />
                  <span className="text-[10px]">CODE MODE</span>
                </span>
              )}
            </div>
            <div className="text-2xl font-bold text-white tracking-tight">
              {sessionData?.interview?.title || "Evaluation"}
            </div>
            <div className="text-muted-foreground text-xs font-mono mt-0.5">
              CANDIDATE: {sessionData?.session?.candidateName} // ID: {sessionData?.session?.id}
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-2 w-64">
          <div className="flex items-center gap-3 w-full">
            <div className="flex-1 text-right">
              <div className="text-xs font-display tracking-widest text-muted-foreground uppercase mb-1">Time Remaining</div>
              <div className={`text-xl font-mono font-bold tracking-wider ${
                isCriticalTime ? 'text-red-500 animate-pulse' : isLowTime ? 'text-yellow-400' : 'text-primary'
              }`}>
                <Clock className="w-4 h-4 inline-block mr-1 -mt-0.5" />
                {countdown !== null ? formatTime(countdown) : '--:--'}
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs font-display tracking-widest text-muted-foreground uppercase mb-1">Questions</div>
              <div className="text-xl font-mono text-accent font-bold">
                {sessionData?.session?.questionsAsked || 0}
              </div>
            </div>
          </div>

          <div className="w-full bg-white/10 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${
                isCriticalTime ? 'bg-red-500' : isLowTime ? 'bg-yellow-400' : 'bg-primary'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <StrictnessMeter level={sessionData?.session?.currentStrictness || 5} />
        </div>
      </header>

      {codingEnabled && (
        <div className="md:hidden relative z-10 flex border-b border-white/10">
          <button
            onClick={() => setMobileTab('interview')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-mono transition-colors ${
              mobileTab === 'interview' ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-white/40 hover:text-white/60'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> Interview
          </button>
          <button
            onClick={() => setMobileTab('code')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-mono transition-colors ${
              mobileTab === 'code' ? 'text-accent border-b-2 border-accent bg-accent/5' : 'text-white/40 hover:text-white/60'
            }`}
          >
            <Code2 className="w-4 h-4" /> Code Editor
          </button>
        </div>
      )}

      {codingEnabled ? (
        <div className="flex-1 relative z-10 flex min-h-0" ref={containerRef}>
          <div className="hidden md:flex flex-col" style={{ width: `${splitPercent}%` }}>
            {interviewPanel}
          </div>

          <div
            className="hidden md:flex items-center justify-center w-2 cursor-col-resize group hover:bg-primary/10 transition-colors flex-shrink-0"
            onMouseDown={handleDividerMouseDown}
          >
            <div className="w-0.5 h-12 bg-white/10 group-hover:bg-primary/40 rounded-full transition-colors" />
          </div>

          <div className="hidden md:block p-3" style={{ width: `calc(${100 - splitPercent}% - 8px)` }}>
            <CodeEditor onSubmitCode={handleSubmitCode} disabled={isTimeUp} sessionId={numSessionId} />
          </div>

          <div className="md:hidden flex-1 flex flex-col">
            {mobileTab === 'interview' ? (
              interviewPanel
            ) : (
              <div className="flex-1 p-3">
                <CodeEditor onSubmitCode={handleSubmitCode} disabled={isTimeUp} sessionId={numSessionId} />
              </div>
            )}
          </div>
        </div>
      ) : (
        interviewPanel
      )}
    </div>
  );
}
