import { useState } from "react";
import { useLocation } from "wouter";
import { BrainCircuit, Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCreateSessionMutation } from "@/hooks/use-sessions";
import { useToast } from "@/hooks/use-toast";

export default function CandidateJoin() {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const defaultId = searchParams.get('id') || "";
  
  const [interviewId, setInterviewId] = useState(defaultId);
  const [candidateName, setCandidateName] = useState("");
  
  const createSession = useCreateSessionMutation();
  const { toast } = useToast();

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!interviewId || !candidateName) return;

    try {
      const session = await createSession.mutateAsync({
        data: {
          interviewId: parseInt(interviewId, 10),
          candidateName
        }
      });
      
      // Request microphone permissions before entering the screen
      await navigator.mediaDevices.getUserMedia({ audio: true });
      
      setLocation(`/interview/${session.id}`);
    } catch (err: any) {
      toast({
        title: "Connection Failed",
        description: err.message || "Invalid Interview ID or network error.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative">
      <div className="fixed inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-30 pointer-events-none mix-blend-screen" />
      
      <Card className="w-full max-w-md relative z-10 border-primary/20 shadow-[0_0_50px_rgba(0,229,255,0.1)]">
        <CardHeader className="text-center pb-8">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 border border-primary/30 shadow-[0_0_20px_rgba(0,229,255,0.2)]">
            <BrainCircuit className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-3xl neon-text">System Access</CardTitle>
          <CardDescription>Enter your credentials to begin evaluation</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleJoin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-display tracking-widest uppercase text-primary/70">Candidate Name</label>
              <Input 
                required 
                placeholder="John Doe" 
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                className="h-14 text-lg border-white/10 bg-black/40 focus-visible:ring-primary focus-visible:border-primary"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-xs font-display tracking-widest uppercase text-primary/70">Interview Access Code</label>
              <Input 
                required 
                placeholder="ID Number" 
                value={interviewId}
                onChange={(e) => setInterviewId(e.target.value)}
                className="h-14 text-lg border-white/10 bg-black/40 font-mono focus-visible:ring-primary focus-visible:border-primary"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 text-lg tracking-wide uppercase font-display mt-4"
              disabled={createSession.isPending}
            >
              {createSession.isPending ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Establishing Uplink</>
              ) : (
                "Initialize Session"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
