import { format } from "date-fns";
import { Users, Clock, BrainCircuit, Trash2 } from "lucide-react";
import { useInterviews, useDeleteInterviewMutation } from "@/hooks/use-interviews";
import { CreateInterviewDialog } from "@/components/CreateInterviewDialog";
import { CandidateManager } from "@/components/CandidateManager";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { data: interviews, isLoading } = useInterviews();
  const deleteMutation = useDeleteInterviewMutation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8 flex items-center justify-center">
        <div className="animate-pulse-glow w-16 h-16 rounded-full bg-primary/20 border-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background relative selection:bg-primary/30">
      <div className="fixed inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-10 pointer-events-none" />
      
      <main className="max-w-7xl mx-auto p-6 md:p-12 relative z-10">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold neon-text mb-2 text-transparent bg-clip-text bg-gradient-to-r from-white to-white/70">
              EaseMy<span className="text-primary">Hire</span>
            </h1>
            <p className="text-muted-foreground font-display tracking-wide">Hiring made easy</p>
          </div>
          <CreateInterviewDialog />
        </header>

        {(!interviews || interviews.length === 0) ? (
          <div className="flex flex-col items-center justify-center py-24 text-center border border-white/5 rounded-3xl bg-card/30 backdrop-blur-sm">
            <BrainCircuit className="w-16 h-16 text-primary/40 mb-4" />
            <h3 className="text-xl font-medium mb-2">No active paradigms found</h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Initialize a new interview paradigm to begin evaluating candidates autonomously.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {interviews.map((interview) => (
              <Card key={interview.id} className="group hover:border-primary/50 transition-colors duration-500">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <CardTitle className="text-xl group-hover:text-primary transition-colors">
                        {interview.title}
                      </CardTitle>
                      <CardDescription className="uppercase tracking-widest text-xs font-bold text-accent">
                        {interview.experienceLevel.toUpperCase()} Mode
                      </CardDescription>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 -mt-2 -mr-2"
                      onClick={() => deleteMutation.mutate({ id: interview.id })}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-primary/70" />
                      <span>{interview.durationMinutes}m</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-primary/70" />
                      <span>{interview.voiceGender}</span>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground/70 line-clamp-3">
                    {interview.jobDescription}
                  </div>
                </CardContent>
                <CardFooter className="pt-4 border-t border-white/5 flex justify-between items-center">
                  <div className="text-xs text-muted-foreground">
                    {format(new Date(interview.createdAt), "MMM d, yyyy")}
                  </div>
                  <CandidateManager interviewId={interview.id} interviewTitle={interview.title} />
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
