import { useEffect, useState } from "react";
import { useParams, Link } from "wouter";
import confetti from "canvas-confetti";
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from "recharts";
import { Trophy, ArrowLeft, Target, Zap, ShieldAlert, Award, Camera, Eye, ShieldCheck, CheckCircle, XCircle } from "lucide-react";
import { useSession } from "@/hooks/use-sessions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

function VerdictBadge({ verdict }: { verdict: string }) {
  const colors: Record<string, string> = {
    "STRONG HIRE": "bg-green-500/20 text-green-400 border-green-500/30",
    "HIRE": "bg-green-500/15 text-green-400 border-green-500/20",
    "LEAN HIRE": "bg-yellow-500/15 text-yellow-300 border-yellow-500/20",
    "LEAN NO HIRE": "bg-orange-500/15 text-orange-400 border-orange-500/20",
    "NO HIRE": "bg-red-500/15 text-red-400 border-red-500/20",
    "STRONG NO HIRE": "bg-red-500/20 text-red-400 border-red-500/30",
  };
  const style = colors[verdict] || "bg-white/10 text-white border-white/20";

  return (
    <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-bold tracking-widest uppercase ${style}`}>
      <Award className="w-4 h-4" />
      {verdict}
    </div>
  );
}

export default function Results() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const numSessionId = parseInt(sessionId, 10);
  const { data: sessionData, isLoading } = useSession(numSessionId);
  const [evaluation, setEvaluation] = useState<any>(null);
  const [loadingEval, setLoadingEval] = useState(false);

  useEffect(() => {
    if (!sessionData?.session) return;

    if (sessionData.session.status === 'active' && !loadingEval) {
      setLoadingEval(true);
      fetch(`/api/sessions/${numSessionId}/end`, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          setEvaluation(data);
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#00E5FF', '#7000FF', '#ffffff']
          });
        })
        .catch(console.error)
        .finally(() => setLoadingEval(false));
    } else if (sessionData.session.status === 'completed' && !evaluation && !loadingEval) {
      setLoadingEval(true);
      fetch(`/api/sessions/${numSessionId}/end`, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data.scores) {
            setEvaluation(data);
          } else {
            let feedbackText = sessionData.session.feedback || "";
            try {
              const parsed = JSON.parse(feedbackText);
              if (parsed.text) feedbackText = parsed.text;
            } catch {}
            setEvaluation({
              scores: { overall: sessionData.session.overallScore || 50 },
              feedback: feedbackText || "Interview evaluation complete.",
              strengths: ["Completed the interview"],
              improvements: ["Review results with the organizer"],
              aiSuspicionReport: "No data available for this session.",
              finalVerdict: "N/A"
            });
          }
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#00E5FF', '#7000FF', '#ffffff']
          });
        })
        .catch(() => {
          setEvaluation({
            scores: { overall: sessionData.session.overallScore || 50 },
            feedback: sessionData.session.feedback || "Interview evaluation complete.",
            strengths: [],
            improvements: [],
            aiSuspicionReport: "",
            finalVerdict: ""
          });
        })
        .finally(() => setLoadingEval(false));
    }
  }, [sessionData, numSessionId]);

  if (isLoading || !sessionData || loadingEval) {
    return (
      <div className="min-h-screen bg-background p-8 flex flex-col items-center justify-center gap-4">
        <div className="w-16 h-16 rounded-full bg-primary/20 border-2 border-primary animate-pulse"></div>
        <p className="text-muted-foreground font-mono">Generating Comprehensive Evaluation Report...</p>
        <p className="text-muted-foreground/50 text-sm font-mono">Analyzing emotions, confidence, knowledge depth, and AI detection...</p>
      </div>
    );
  }

  const hasCodeQuality = evaluation?.scores?.codeQuality != null;
  const chartData = evaluation ? [
    { subject: 'Technical', A: evaluation.scores.technical, fullMark: 100 },
    { subject: 'Communication', A: evaluation.scores.communication, fullMark: 100 },
    { subject: 'Problem Solving', A: evaluation.scores.problemSolving, fullMark: 100 },
    { subject: 'Confidence', A: evaluation.scores.confidence, fullMark: 100 },
    { subject: 'Depth', A: evaluation.scores.depthOfUnderstanding, fullMark: 100 },
    { subject: 'Resilience', A: evaluation.scores.emotionalResilience, fullMark: 100 },
    { subject: 'Under Pressure', A: evaluation.scores.pressureHandling, fullMark: 100 },
    ...(hasCodeQuality ? [{ subject: 'Code Quality', A: evaluation.scores.codeQuality, fullMark: 100 }] : []),
  ] : [];

  return (
    <div className="min-h-screen bg-background p-6 md:p-12 relative overflow-hidden">
      <div className="fixed inset-0 bg-[url('/images/sci-fi-bg.png')] bg-cover bg-center opacity-10 pointer-events-none" />
      
      <div className="max-w-5xl mx-auto relative z-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/">
            <Button variant="outline" size="icon" className="rounded-full">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold">Evaluation Report</h1>
            <p className="text-muted-foreground font-mono text-sm">Session ID: {sessionData.session.id} // Candidate: {sessionData.session.candidateName}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1 bg-primary/10 border-primary/30 flex flex-col items-center justify-center p-8 text-center shadow-[0_0_50px_rgba(0,229,255,0.1)]">
            <Trophy className="w-16 h-16 text-primary mb-4" />
            <div className="text-7xl font-bold text-white mb-2">
              {evaluation?.scores?.overall || '--'}
            </div>
            <div className="text-primary tracking-widest uppercase text-sm mb-4">Overall Score</div>
            {evaluation?.finalVerdict && evaluation.finalVerdict !== "N/A" && (
              <VerdictBadge verdict={evaluation.finalVerdict} />
            )}
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Comprehensive Skill Matrix</CardTitle>
              <CardDescription>{hasCodeQuality ? '8' : '7'}-dimension evaluation across technical and behavioral competencies</CardDescription>
            </CardHeader>
            <CardContent className="h-[350px] flex items-center justify-center">
              {evaluation && (
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="75%" data={chartData}>
                    <PolarGrid stroke="rgba(255,255,255,0.1)" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 11 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                    <Radar
                      name="Score"
                      dataKey="A"
                      stroke="#00E5FF"
                      fill="#00E5FF"
                      fillOpacity={0.4}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-yellow-400" />
                AI Integrity Check
              </CardTitle>
              <CardDescription>Analysis of whether the candidate appeared to use AI tools or read from external sources</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-4 rounded-xl bg-yellow-500/5 border border-yellow-500/20 text-white/80 leading-relaxed text-sm">
                {evaluation?.aiSuspicionReport || "No AI detection data available."}
              </div>
            </CardContent>
          </Card>

          {(() => {
            const sess = sessionData?.session as any;
            const interv = sessionData?.interview as any;
            const idVerified = sess?.idVerified;
            const idData = sess?.idVerificationData as Record<string, unknown> | null;
            if (!interv?.idVerificationRequired) return null;
            return (
              <Card className="md:col-span-3">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-primary" />
                    ID Verification
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-3">
                    {idVerified ? (
                      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-green-500/10 border border-green-500/20">
                        <CheckCircle className="w-5 h-5 text-green-400" />
                        <div>
                          <p className="text-sm font-medium text-green-400">Identity Verified</p>
                          {idData && (
                            <p className="text-xs text-white/50">
                              {(idData.idType as string) || "Government ID"} — Name: {(idData.nameOnId as string) || "N/A"} — Confidence: {(idData.confidence as number) ?? "N/A"}%
                            </p>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/20">
                        <XCircle className="w-5 h-5 text-red-400" />
                        <p className="text-sm font-medium text-red-400">ID Not Verified</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })()}

          {(() => {
            const sess = sessionData?.session as any;
            const tabCount = sess?.tabSwitchCount || 0;
            const focusCount = sess?.focusLostCount || 0;
            const flags: string[] = Array.isArray(sess?.proctoringFlags) ? sess.proctoringFlags : [];
            const pasteCount = flags.filter((f: string) => f.startsWith("PASTE_DETECTED")).length;
            const lookAwayCount = flags.filter((f: string) => f.startsWith("LOOKING_AWAY")).length;
            const totalViolations = tabCount + focusCount + pasteCount + lookAwayCount;
            if (totalViolations === 0) return null;

            return (
              <Card className="md:col-span-3">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="w-5 h-5 text-red-400" />
                    Proctoring Report
                  </CardTitle>
                  <CardDescription>Activity monitoring detected the following during the interview</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-center">
                      <div className="text-2xl font-bold text-red-400">{tabCount}</div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Tab Switches</div>
                    </div>
                    <div className="p-4 rounded-xl bg-orange-500/10 border border-orange-500/20 text-center">
                      <div className="text-2xl font-bold text-orange-400">{focusCount}</div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Focus Lost</div>
                    </div>
                    {pasteCount > 0 && (
                      <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20 text-center">
                        <div className="text-2xl font-bold text-purple-400">{pasteCount}</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Paste Events</div>
                      </div>
                    )}
                    {lookAwayCount > 0 && (
                      <div className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-center">
                        <div className="text-2xl font-bold text-yellow-400">{lookAwayCount}</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">Looking Away</div>
                      </div>
                    )}
                    <div className={`p-4 rounded-xl border text-center ${pasteCount === 0 && lookAwayCount === 0 ? "col-span-2" : "col-span-full"} flex items-center justify-center gap-2 ${
                      totalViolations > 8 ? "bg-red-500/10 border-red-500/20" : totalViolations > 3 ? "bg-orange-500/10 border-orange-500/20" : "bg-white/5 border-white/10"
                    }`}>
                      <Eye className="w-4 h-4 text-primary" />
                      <span className="text-sm text-muted-foreground">
                        {totalViolations > 8
                          ? "CRITICAL: High suspicious activity — multiple cheating indicators detected"
                          : totalViolations > 3
                            ? "WARNING: Moderate suspicious activity — review recommended"
                            : "Minor activity flags — low concern"}
                      </span>
                    </div>
                  </div>
                  {pasteCount > 0 && (
                    <div className="mt-4 p-3 rounded-lg bg-purple-500/5 border border-purple-500/10">
                      <p className="text-xs text-purple-300 font-mono uppercase tracking-wider mb-2">Paste Activity Log</p>
                      <div className="space-y-1">
                        {flags.filter((f: string) => f.startsWith("PASTE_DETECTED")).map((f: string, i: number) => {
                          const parts = f.split("|");
                          const detail = parts.slice(2).join("|");
                          return (
                            <p key={i} className="text-xs text-muted-foreground font-mono truncate">
                              {detail || "Pasted content detected in code editor"}
                            </p>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })()}

          <Card className="md:col-span-3">
            <CardHeader>
              <CardTitle>Detailed Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Technical', score: evaluation?.scores?.technical, color: 'text-blue-400' },
                  { label: 'Communication', score: evaluation?.scores?.communication, color: 'text-sky-400' },
                  { label: 'Problem Solving', score: evaluation?.scores?.problemSolving, color: 'text-purple-400' },
                  { label: 'Confidence', score: evaluation?.scores?.confidence, color: 'text-green-400' },
                  { label: 'Depth', score: evaluation?.scores?.depthOfUnderstanding, color: 'text-amber-400' },
                  { label: 'Resilience', score: evaluation?.scores?.emotionalResilience, color: 'text-pink-400' },
                  { label: 'Under Pressure', score: evaluation?.scores?.pressureHandling, color: 'text-red-400' },
                  ...(hasCodeQuality ? [{ label: 'Code Quality', score: evaluation?.scores?.codeQuality, color: 'text-emerald-400' }] : []),
                  { label: 'Overall', score: evaluation?.scores?.overall, color: 'text-primary' },
                ].map(({ label, score, color }) => (
                  <div key={label} className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
                    <div className={`text-3xl font-bold ${color} mb-1`}>{score ?? '--'}</div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div>
                    <div className="w-full bg-white/10 rounded-full h-1 mt-2">
                      <div className={`h-full rounded-full bg-current ${color}`} style={{ width: `${score || 0}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-3">
            <CardHeader>
              <CardTitle>AI Synthesis</CardTitle>
              <CardDescription>Comprehensive behavioral and technical breakdown.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="p-6 rounded-xl bg-white/5 border border-white/10 leading-relaxed text-white/90">
                {evaluation?.feedback || "Awaiting processing..."}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="flex items-center gap-2 text-lg text-green-400">
                    <Target className="w-5 h-5" /> Key Strengths
                  </h4>
                  <ul className="space-y-2">
                    {evaluation?.strengths?.map((s: string, i: number) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-1.5 shrink-0" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-4">
                  <h4 className="flex items-center gap-2 text-lg text-accent">
                    <Zap className="w-5 h-5" /> Growth Vectors
                  </h4>
                  <ul className="space-y-2">
                    {evaluation?.improvements?.map((s: string, i: number) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent mt-1.5 shrink-0" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {sessionData.messages && sessionData.messages.length > 0 && (
                <div className="space-y-4">
                  <h4 className="text-lg font-medium">Interview Transcript</h4>
                  <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                    {sessionData.messages.map((msg: any) => (
                      <div key={msg.id} className={`p-3 rounded-lg text-sm ${
                        msg.role === 'interviewer' 
                          ? 'bg-primary/10 border border-primary/20 text-white/90' 
                          : msg.role === 'code'
                          ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-300'
                          : 'bg-white/5 border border-white/10 text-muted-foreground'
                      }`}>
                        <span className="text-xs uppercase tracking-wider font-bold block mb-1 opacity-60">
                          {msg.role === 'interviewer' ? 'AI Interviewer' : msg.role === 'code' ? 'Code Submission' : 'Candidate'}
                        </span>
                        {msg.role === 'code' ? (
                          <pre className="whitespace-pre-wrap font-mono text-xs">{msg.content}</pre>
                        ) : msg.content}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
