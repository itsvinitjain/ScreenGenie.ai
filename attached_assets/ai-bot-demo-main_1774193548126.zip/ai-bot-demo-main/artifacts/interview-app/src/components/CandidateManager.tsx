import { useState, useEffect, useCallback } from "react";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, Plus, Copy, Check, Trash2, ExternalLink, UserCheck, Clock, Mail } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface Candidate {
  id: number;
  interviewId: number;
  name: string;
  email: string | null;
  inviteToken: string;
  status: string;
  sessionId: number | null;
  createdAt: string;
}

const API_BASE = `${import.meta.env.BASE_URL}api`.replace(/\/+/g, "/");

function getInviteUrl(token: string): string {
  return `${window.location.origin}${import.meta.env.BASE_URL}invite/${token}`;
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    invited: { label: "Invited", variant: "outline" },
    started: { label: "In Progress", variant: "secondary" },
    completed: { label: "Completed", variant: "default" },
  };
  const { label, variant } = config[status] || { label: status, variant: "outline" as const };
  return <Badge variant={variant}>{label}</Badge>;
}

export function CandidateManager({ interviewId, interviewTitle }: { interviewId: number; interviewTitle: string }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data: candidates = [], isLoading } = useQuery<Candidate[]>({
    queryKey: ["candidates", interviewId],
    queryFn: () => fetch(`${API_BASE}/interviews/${interviewId}/candidates`).then(r => r.json()),
    enabled: open,
  });

  const addMutation = useMutation({
    mutationFn: (data: { name: string; email?: string }) =>
      fetch(`${API_BASE}/interviews/${interviewId}/candidates`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidates: [data] }),
      }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["candidates", interviewId] });
      setName("");
      setEmail("");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      fetch(`${API_BASE}/candidates/${id}`, { method: "DELETE" }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["candidates", interviewId] });
    },
  });

  const handleAdd = useCallback(() => {
    if (!name.trim()) return;
    addMutation.mutate({ name: name.trim(), email: email.trim() || undefined });
  }, [name, email, addMutation]);

  const handleCopy = useCallback((candidate: Candidate) => {
    navigator.clipboard.writeText(getInviteUrl(candidate.inviteToken));
    setCopiedId(candidate.id);
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  useEffect(() => {
    if (!open) {
      setCopiedId(null);
    }
  }, [open]);

  const completedCount = candidates.filter(c => c.status === "completed").length;
  const startedCount = candidates.filter(c => c.status === "started").length;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="text-primary hover:text-white gap-1.5">
          <Users className="w-4 h-4" />
          Candidates
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl">
            Manage Candidates — {interviewTitle}
          </DialogTitle>
          {candidates.length > 0 && (
            <p className="text-sm text-muted-foreground mt-1">
              {candidates.length} invited · {startedCount} in progress · {completedCount} completed
            </p>
          )}
        </DialogHeader>

        <div className="flex gap-2 mt-4">
          <Input
            placeholder="Candidate name"
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleAdd()}
            className="flex-1"
          />
          <Input
            placeholder="Email (optional)"
            value={email}
            onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleAdd()}
            className="flex-1"
            type="email"
          />
          <Button onClick={handleAdd} disabled={!name.trim() || addMutation.isPending} size="icon" className="shrink-0">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto mt-4 space-y-2 min-h-0">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading candidates...</div>
          ) : candidates.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>No candidates added yet</p>
              <p className="text-xs mt-1">Add candidates above to generate unique invite links</p>
            </div>
          ) : (
            candidates.map((candidate) => (
              <div
                key={candidate.id}
                className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/10 hover:border-primary/30 transition-colors group"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium truncate">{candidate.name}</span>
                    <StatusBadge status={candidate.status} />
                  </div>
                  {candidate.email && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                      <Mail className="w-3 h-3" />
                      <span className="truncate">{candidate.email}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {candidate.status === "completed" && candidate.sessionId && (
                    <Link href={`/results/${candidate.sessionId}`}>
                      <Button variant="ghost" size="sm" className="text-primary gap-1 text-xs">
                        <ExternalLink className="w-3 h-3" />
                        Results
                      </Button>
                    </Link>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(candidate)}
                    className="gap-1 text-xs"
                  >
                    {copiedId === candidate.id ? (
                      <>
                        <Check className="w-3 h-3 text-green-400" />
                        <span className="text-green-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        Copy Link
                      </>
                    )}
                  </Button>
                  {candidate.status === "invited" && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-muted-foreground hover:text-destructive h-8 w-8"
                      onClick={() => deleteMutation.mutate(candidate.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {candidates.length > 0 && (
          <div className="pt-3 border-t border-white/10 mt-2">
            <Button
              variant="outline"
              size="sm"
              className="w-full text-xs"
              onClick={() => {
                const allLinks = candidates
                  .map(c => `${c.name}: ${getInviteUrl(c.inviteToken)}`)
                  .join("\n");
                navigator.clipboard.writeText(allLinks);
                setCopiedId(-1);
                setTimeout(() => setCopiedId(null), 2000);
              }}
            >
              {copiedId === -1 ? (
                <><Check className="w-3 h-3 mr-1 text-green-400" /> All Links Copied!</>
              ) : (
                <><Copy className="w-3 h-3 mr-1" /> Copy All Links</>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
