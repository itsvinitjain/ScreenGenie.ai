import { useState, useRef, useEffect, useCallback } from "react";
import { Camera, CameraOff, CheckCircle, XCircle, Loader2, ShieldCheck, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";

interface IdVerificationProps {
  sessionId: number;
  candidateName: string;
  onVerified: () => void;
}

interface VerificationResult {
  verified: boolean;
  isValidId?: boolean;
  idType?: string;
  nameOnId?: string;
  nameMatch?: boolean;
  hasPhoto?: boolean;
  confidence?: number;
  reason?: string;
}

export function IdVerification({ sessionId, candidateName, onVerified }: IdVerificationProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [attempts, setAttempts] = useState(0);

  useEffect(() => {
    let mounted = true;
    navigator.mediaDevices
      .getUserMedia({ video: { width: 1280, height: 720, facingMode: "user" }, audio: false })
      .then((stream) => {
        if (!mounted) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
        setCameraReady(true);
      })
      .catch(() => {
        if (mounted) setCameraError(true);
      });

    return () => {
      mounted = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, []);

  const captureAndVerify = useCallback(async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageBase64 = canvas.toDataURL("image/jpeg", 0.9).split(",")[1];
    setCapturedImage(canvas.toDataURL("image/jpeg", 0.9));
    setVerifying(true);
    setResult(null);

    try {
      const res = await fetch(`/api/sessions/${sessionId}/verify-id`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageBase64, candidateName }),
      });

      if (!res.ok) {
        setResult({ verified: false, reason: "Verification service unavailable. Please try again." });
        return;
      }

      const data: VerificationResult = await res.json();
      setResult(data);
      setAttempts((prev) => prev + 1);

      if (data.verified) {
        setTimeout(() => {
          onVerified();
        }, 2000);
      }
    } catch {
      setResult({ verified: false, reason: "Network error. Please try again." });
    } finally {
      setVerifying(false);
    }
  }, [sessionId, candidateName, onVerified]);

  const handleRetry = () => {
    setResult(null);
    setCapturedImage(null);
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-2xl mx-auto">
      <div className="flex items-center gap-3 text-primary">
        <ShieldCheck className="w-8 h-8" />
        <div>
          <h2 className="text-xl font-bold text-white">Government ID Verification</h2>
          <p className="text-sm text-muted-foreground">Required before starting the interview</p>
        </div>
      </div>

      <div className="w-full p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-2">
        <div className="flex items-start gap-2">
          <CreditCard className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
          <div className="text-sm text-white/80 space-y-1">
            <p className="font-medium text-white">Please hold your Government ID in front of the camera</p>
            <ul className="list-disc list-inside text-xs text-white/60 space-y-0.5">
              <li>Accepted: Passport, Driver's License, National ID, Aadhaar, Voter ID</li>
              <li>Ensure the entire ID is visible and well-lit</li>
              <li>Hold it steady — avoid glare and reflections</li>
              <li>The name on your ID should match: <span className="text-primary font-mono">{candidateName}</span></li>
            </ul>
          </div>
        </div>
      </div>

      <div className="relative w-full aspect-video rounded-xl overflow-hidden border-2 border-white/15 bg-black shadow-[0_0_20px_rgba(0,0,0,0.5)]">
        {!capturedImage ? (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
              style={{ display: cameraReady ? "block" : "none" }}
            />
            <canvas ref={canvasRef} className="hidden" />

            {!cameraReady && !cameraError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-white/40">
                <Camera className="w-8 h-8 animate-pulse" />
                <span className="text-xs font-mono">Initializing camera...</span>
              </div>
            )}
            {cameraError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-red-400">
                <CameraOff className="w-8 h-8" />
                <span className="text-xs font-mono">Camera access denied</span>
                <span className="text-[10px] text-red-400/60">Please allow camera access and refresh</span>
              </div>
            )}

            {cameraReady && (
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute inset-[15%] border-2 border-dashed border-primary/40 rounded-lg" />
                <div className="absolute bottom-3 left-0 right-0 text-center">
                  <span className="px-3 py-1 rounded-full bg-black/70 text-[10px] font-mono text-primary uppercase tracking-wider">
                    Position your ID within the frame
                  </span>
                </div>
              </div>
            )}
          </>
        ) : (
          <img src={capturedImage} alt="Captured ID" className="w-full h-full object-cover" />
        )}

        {verifying && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-10 h-10 text-primary animate-spin" />
            <span className="text-sm font-mono text-primary animate-pulse">Verifying your ID...</span>
          </div>
        )}
      </div>

      {result && (
        <div className={`w-full p-4 rounded-xl border ${
          result.verified
            ? "bg-green-500/10 border-green-500/30"
            : "bg-red-500/10 border-red-500/30"
        }`}>
          <div className="flex items-start gap-3">
            {result.verified ? (
              <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
            )}
            <div className="space-y-1.5">
              <p className={`font-bold ${result.verified ? "text-green-400" : "text-red-400"}`}>
                {result.verified ? "ID Verified Successfully" : "Verification Failed"}
              </p>
              {result.reason && (
                <p className="text-xs text-white/60">{result.reason}</p>
              )}
              {result.verified && (
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {result.idType && (
                    <div className="text-xs">
                      <span className="text-white/40">ID Type:</span>{" "}
                      <span className="text-white/80">{result.idType}</span>
                    </div>
                  )}
                  {result.nameOnId && (
                    <div className="text-xs">
                      <span className="text-white/40">Name:</span>{" "}
                      <span className="text-white/80">{result.nameOnId}</span>
                    </div>
                  )}
                  {result.confidence !== undefined && (
                    <div className="text-xs">
                      <span className="text-white/40">Confidence:</span>{" "}
                      <span className="text-white/80">{result.confidence}%</span>
                    </div>
                  )}
                  {result.nameMatch !== undefined && (
                    <div className="text-xs">
                      <span className="text-white/40">Name Match:</span>{" "}
                      <span className={result.nameMatch ? "text-green-400" : "text-yellow-400"}>
                        {result.nameMatch ? "Yes" : "Mismatch"}
                      </span>
                    </div>
                  )}
                </div>
              )}
              {result.verified && (
                <p className="text-xs text-green-400/80 mt-2 font-mono animate-pulse">
                  Proceeding to interview...
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center gap-3">
        {!result ? (
          <Button
            variant="glow"
            size="lg"
            className="w-64 h-12 font-display uppercase tracking-widest"
            onClick={captureAndVerify}
            disabled={!cameraReady || verifying}
          >
            {verifying ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Verifying...</>
            ) : (
              <><Camera className="w-4 h-4 mr-2" /> Capture & Verify</>
            )}
          </Button>
        ) : !result.verified ? (
          <Button
            variant="glow"
            size="lg"
            className="w-64 h-12 font-display uppercase tracking-widest"
            onClick={handleRetry}
          >
            <Camera className="w-4 h-4 mr-2" /> Try Again
          </Button>
        ) : null}
      </div>

      {attempts > 0 && !result?.verified && (
        <p className="text-[10px] text-white/30 font-mono">
          Attempt {attempts} — Make sure your ID is well-lit and fully visible
        </p>
      )}
    </div>
  );
}
