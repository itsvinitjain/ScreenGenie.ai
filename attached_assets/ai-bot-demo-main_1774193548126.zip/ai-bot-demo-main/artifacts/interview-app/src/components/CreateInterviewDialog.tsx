import { useState, useEffect, useRef } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Plus, Loader2, Code2, ShieldCheck, UserCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useCreateInterviewMutation } from "@/hooks/use-interviews";
import { useToast } from "@/hooks/use-toast";

const DEV_KEYWORDS = [
  "engineer", "developer", "programmer", "frontend", "backend", "fullstack",
  "full-stack", "full stack", "software", "web dev", "mobile dev", "devops",
  "sre", "react", "angular", "vue", "node", "python", "java", "golang",
  "rust", "c++", "typescript", "javascript", "coding", "programming",
  "api", "microservice", "cloud", "aws", "gcp", "azure", "data engineer",
  "ml engineer", "machine learning", "ai engineer", "ios", "android",
];

function detectDevRole(title: string, description: string): boolean {
  const combined = `${title} ${description}`.toLowerCase();
  return DEV_KEYWORDS.some((kw) => combined.includes(kw));
}

const MIN_CODING_DURATION = 10;

const formSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  jobDescription: z.string().min(10, "Description must be at least 10 characters"),
  durationMinutes: z.coerce.number().min(5).max(120),
  voiceGender: z.enum(["male", "female"]),
  experienceLevel: z.enum(["fresher", "lenient", "medium", "hard"]),
  codingEnabled: z.boolean(),
  humanAvatarEnabled: z.boolean(),
  idVerificationRequired: z.boolean(),
  questions: z.string().optional(),
}).refine(
  (data) => !data.codingEnabled || data.durationMinutes >= MIN_CODING_DURATION,
  { message: `Coding requires at least ${MIN_CODING_DURATION} minutes duration`, path: ["codingEnabled"] }
);

type FormValues = z.infer<typeof formSchema>;

export function CreateInterviewDialog() {
  const [open, setOpen] = useState(false);
  const createMutation = useCreateInterviewMutation();
  const { toast } = useToast();

  const { register, handleSubmit, formState: { errors, isSubmitting }, reset, control, setValue } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      durationMinutes: 30,
      voiceGender: "female",
      experienceLevel: "medium",
      codingEnabled: false,
      humanAvatarEnabled: false,
      idVerificationRequired: false,
    }
  });

  const watchedTitle = useWatch({ control, name: "title" });
  const watchedDescription = useWatch({ control, name: "jobDescription" });
  const watchedDuration = useWatch({ control, name: "durationMinutes" });
  const watchedCoding = useWatch({ control, name: "codingEnabled" });
  const autoDetected = detectDevRole(watchedTitle || "", watchedDescription || "");
  const prevAutoDetected = useRef(false);
  const durationTooShort = (watchedDuration || 0) < MIN_CODING_DURATION;

  useEffect(() => {
    if (autoDetected && !prevAutoDetected.current && !durationTooShort) {
      setValue("codingEnabled", true);
    }
    prevAutoDetected.current = autoDetected;
  }, [autoDetected, setValue, durationTooShort]);

  useEffect(() => {
    if (durationTooShort && watchedCoding) {
      setValue("codingEnabled", false);
    }
  }, [durationTooShort, watchedCoding, setValue]);

  const onSubmit = async (data: FormValues) => {
    try {
      const questionsArray = data.questions 
        ? data.questions.split('\n').filter(q => q.trim().length > 0)
        : [];

      await createMutation.mutateAsync({
        data: {
          title: data.title,
          jobDescription: data.jobDescription,
          durationMinutes: data.durationMinutes,
          voiceGender: data.voiceGender,
          experienceLevel: data.experienceLevel,
          codingEnabled: data.codingEnabled,
          humanAvatarEnabled: data.humanAvatarEnabled,
          idVerificationRequired: data.idVerificationRequired,
          questions: questionsArray,
        }
      });

      toast({ title: "Interview created successfully" });
      setOpen(false);
      reset();
    } catch (err) {
      toast({ 
        title: "Failed to create interview", 
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive" 
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="glow" className="gap-2">
          <Plus className="w-4 h-4" /> New Interview
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Configure AI Interview</DialogTitle>
          <DialogDescription>
            Set up the parameters for the AI interviewer. The AI will adapt its behavior based on these settings.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Role Title</label>
            <Input placeholder="e.g. Senior Frontend Engineer" {...register("title")} />
            {errors.title && <p className="text-xs text-destructive">{errors.title.message}</p>}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Job Description</label>
            <Textarea 
              placeholder="Paste the full job description here..." 
              className="h-32"
              {...register("jobDescription")} 
            />
            {errors.jobDescription && <p className="text-xs text-destructive">{errors.jobDescription.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Duration (min)</label>
              <Input type="number" {...register("durationMinutes")} />
              {errors.durationMinutes && <p className="text-xs text-destructive">{errors.durationMinutes.message}</p>}
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Difficulty Mode</label>
              <select 
                className="flex h-12 w-full rounded-xl border border-white/10 bg-background/50 px-4 py-2 text-sm text-foreground focus-visible:ring-2 focus-visible:ring-primary/50 outline-none"
                {...register("experienceLevel")}
              >
                <option value="fresher">Fresher (Very Easy)</option>
                <option value="lenient">Lenient (Easy)</option>
                <option value="medium">Medium (Standard)</option>
                <option value="hard">Hard (Expert)</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">AI Voice</label>
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center space-x-2 border border-white/10 rounded-lg p-3 cursor-pointer hover:bg-white/5">
                <input type="radio" value="female" {...register("voiceGender")} className="accent-primary" />
                <span>Female (Nova)</span>
              </label>
              <label className="flex items-center space-x-2 border border-white/10 rounded-lg p-3 cursor-pointer hover:bg-white/5">
                <input type="radio" value="male" {...register("voiceGender")} className="accent-primary" />
                <span>Male (Onyx)</span>
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <label className={`flex items-center justify-between group ${durationTooShort ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}>
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">Live Code Editor</span>
                {autoDetected && !durationTooShort && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-primary/20 text-primary font-mono uppercase tracking-wider">
                    Auto-detected
                  </span>
                )}
              </div>
              <div className="relative">
                <input
                  type="checkbox"
                  {...register("codingEnabled")}
                  disabled={durationTooShort}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-white/10 peer-focus:ring-2 peer-focus:ring-primary/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary/60 peer-disabled:opacity-40" />
              </div>
            </label>
            {durationTooShort ? (
              <p className="text-xs text-amber-400/80 ml-6">
                Coding requires at least {MIN_CODING_DURATION} minutes. Increase the duration to enable this feature.
              </p>
            ) : (
              <p className="text-xs text-muted-foreground ml-6">
                Provides a split-screen code editor during the interview for coding questions. Supports 20 languages including JavaScript, Python, Java, C++, Go, Rust, C#, and more.
              </p>
            )}
            {errors.codingEnabled && <p className="text-xs text-destructive ml-6">{errors.codingEnabled.message}</p>}
          </div>

          <div className="space-y-2">
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-2">
                <UserCircle className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">Human Avatar Interviewer</span>
              </div>
              <div className="relative">
                <input
                  type="checkbox"
                  {...register("humanAvatarEnabled")}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-white/10 peer-focus:ring-2 peer-focus:ring-primary/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary/60" />
              </div>
            </label>
            <p className="text-xs text-muted-foreground ml-6">
              Replace the AI orb with a realistic human avatar that shows expressions, body language, and reacts naturally during the interview.
            </p>
          </div>

          <div className="space-y-2">
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">Government ID Verification</span>
              </div>
              <div className="relative">
                <input
                  type="checkbox"
                  {...register("idVerificationRequired")}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-white/10 peer-focus:ring-2 peer-focus:ring-primary/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary/60" />
              </div>
            </label>
            <p className="text-xs text-muted-foreground ml-6">
              Candidates must verify their identity by showing a government-issued photo ID before the interview begins. ID is validated via AI.
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Custom Questions (Optional)</label>
            <Textarea 
              placeholder="One question per line. The AI will weave these into the conversation." 
              {...register("questions")} 
            />
          </div>

          <div className="flex justify-end pt-4">
            <Button type="submit" disabled={isSubmitting || createMutation.isPending} className="w-full sm:w-auto">
              {(isSubmitting || createMutation.isPending) ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Deploying System...</>
              ) : (
                "Initialize Interview"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
