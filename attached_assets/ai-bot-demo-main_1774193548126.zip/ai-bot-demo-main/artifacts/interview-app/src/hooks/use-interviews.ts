import { 
  useListInterviews, 
  useCreateInterview, 
  useUpdateInterview, 
  useDeleteInterview,
  useListInterviewSessions
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getListInterviewsQueryKey, getListInterviewSessionsQueryKey } from "@workspace/api-client-react";

export function useInterviews() {
  return useListInterviews();
}

export function useInterviewSessionsList(interviewId: number) {
  return useListInterviewSessions(interviewId, {
    query: {
      enabled: !!interviewId,
    }
  });
}

export function useCreateInterviewMutation() {
  const queryClient = useQueryClient();
  return useCreateInterview({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListInterviewsQueryKey() });
      }
    }
  });
}

export function useUpdateInterviewMutation() {
  const queryClient = useQueryClient();
  return useUpdateInterview({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListInterviewsQueryKey() });
      }
    }
  });
}

export function useDeleteInterviewMutation() {
  const queryClient = useQueryClient();
  return useDeleteInterview({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListInterviewsQueryKey() });
      }
    }
  });
}
