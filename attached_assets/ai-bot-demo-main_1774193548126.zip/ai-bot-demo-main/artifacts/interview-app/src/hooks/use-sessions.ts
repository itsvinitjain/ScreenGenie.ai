import { 
  useCreateSession, 
  useGetSession, 
  useEndSession,
  getGetSessionQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useCreateSessionMutation() {
  return useCreateSession();
}

export function useSession(sessionId: number) {
  return useGetSession(sessionId, {
    query: {
      enabled: !!sessionId,
      refetchInterval: (query) => {
        // Stop polling if completed
        if (query.state.data?.session?.status === 'completed') return false;
        return 5000; // Poll every 5s otherwise to catch status updates
      }
    }
  });
}

export function useEndSessionMutation() {
  const queryClient = useQueryClient();
  return useEndSession({
    mutation: {
      onSuccess: (_, variables) => {
        queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey(variables.id) });
      }
    }
  });
}
